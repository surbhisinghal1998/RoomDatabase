package com.solution.s.roomdatabasedemo;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    EditText edit;
    Button save, reset;
    RecyclerView recycler;

    List<MainData> dataList = new ArrayList<>();

    RoomDB database;

    MainAdapter mainAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edit = findViewById(R.id.edittext);
        save = findViewById(R.id.save);
        reset = findViewById(R.id.reset);
        recycler = findViewById(R.id.recycler);

        database = RoomDB.getInstance(this);
        dataList = database.mainDao().getAll();
        mainAdapter = new MainAdapter(MainActivity.this, dataList);
        recycler.setAdapter(mainAdapter);
        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String sText = edit.getText().toString().trim();

                if (!sText.equals("")) {
                    MainData data = new MainData();
                    data.setText(sText);
                    database.mainDao().insert(data);
                    edit.setText("");
                    dataList.clear();
                    dataList.addAll(database.mainDao().getAll());
                    mainAdapter.notifyDataSetChanged();
                }
            }
        });
        reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
database.mainDao().reset(dataList);
dataList.clear();
dataList.addAll(database.mainDao().getAll());
mainAdapter.notifyDataSetChanged();
            }
        });
    }
}
